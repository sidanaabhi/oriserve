#!/bin/bash
# Start web server (Assuming you're using Apache here)
sudo systemctl start httpd   # For Amazon Linux 2
